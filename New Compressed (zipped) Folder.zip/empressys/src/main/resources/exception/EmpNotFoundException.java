package exception;

public class EmpNotFoundException extends Exception{

	@Override
	public String getMessage() {
		return "Employee not found!";
	}
}
