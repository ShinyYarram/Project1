package exception;

public class InvalidRequestException extends Exception {
private String message;
public InvalidRequestException() {
	this.message="Invalid request!";
}
@Override
public String getMessage() {
	return this.message;
}
}
