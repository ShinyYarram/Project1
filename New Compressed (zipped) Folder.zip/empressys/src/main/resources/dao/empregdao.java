package dao;
import java.util.List;
import entity.Employee;
import model.Employee;
public interface empregdao {
	 public void addEmployee(Employee e);
	 public List<String> getEmployeeIds();
	 public Employee getEmployeeById(int id);
	 public Employee getEmployeeByIdAndName(String employeeId, String fname, String lname);
	 public Employee getEmployeeById(String employeeId);
	 public List<Employee> getAllEmployees();
	 public void updateEmployee(Employee employee, EmpField field, String newVal);
	 public void updateEmployee(Employee employee, Position newPos);
	 public void deleteEmployee(Employee employee);
	

}
