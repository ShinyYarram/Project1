package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import db.DBUtil;
import model.Employee;
import hibernate.Session;
import hibernate.query.Query;
import db.EmployeeMapper;
import db.HibernateUtil;
import entity.Employee;
public class empregdaoimpl implements empregdao {
final static Logger log = Logger.getLogger(empregdaoimpl.class);
	
	private static empregdaoimpl instance;
	
	private empregdaoimpl() {
		
	}
	
	public static empregdaoimpl getempregdaoimpl() {
		instance = instance == null ? new empregdaoimpl() : instance;
		return instance;
	}
	
	 public void addEmployee(Employee e) {
		
		
			try {
				String sql = "CALL add_employee(?,?,?,?,?,?,?,?,?,?)";
				
				List<String> employeeIds = this.getEmployeeIds();
				if(employeeIds.contains(employee.getEmployeeId())) {
					throw new EmployeeException();
				}
			Connection con=DBUtil.getConnection();
			if(conn == null) {
				log.warn("Problem connectiong to jdbc");
				return;
			}
			CallableStatement cs = conn.prepareCall(sql);
			
			int i = 0;
			cs.setString(++i, employee.getFname());
			cs.setString(++i, employee.getLname());
			cs.setString(++i, employee.getPosition().getPosition());
			cs.setString(++i, employee.getEmployeeId());
			cs.setString(++i, employee.getStreet());
			cs.setString(++i, employee.getCity());
			cs.setString(++i, employee.getState());
			cs.setString(++i, employee.getZip());
			cs.setString(++i, employee.getPhone());
			cs.setString(++i, employee.getEmail());
			
			cs.executeUpdate();
			System.out.println("******data inserted*******");
			
		} catch(SQLException e) {
			e.printStackTrace();
			log.error(e.getCause());
			log.error(e.getMessage());
		}
	}
	 public List<String> getEmployeeIds() {
			List<Employee> employees = this.getAllEmployees();
			if(employees == null) {
				log.warn("Null employees, check jdbc connection");
				return null;
			}
			List<String> employeeIds = new ArrayList<String>();
			
			for(Employee emp: employees) {
				employeeIds.add(emp.getEmployeeId());
			}
			
			return employeeIds;
		}
	 public Employee getEmployeeById(int id) {
			try {
				String sql = String.format("SELECT * FROM employees WHERE u_id = ?");
				
				Connection conn = DBUtil.getConnection();
				if(conn == null) {
					log.warn("Problem connectiong to jdbc");
					return null;
				}
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setInt(1, id);
				
				ResultSet rs = ps.executeQuery();
				
				while(rs.next()) {
					return new Employee(
							rs.getInt("u_id"),
							rs.getString("fname"),
							rs.getString("lname"), 
							rs.getString("employeeid"), 
							Position.fromString(rs.getString("position")), 
							rs.getString("street"), 
							rs.getString("city"), 
							rs.getString("state"), 
							rs.getString("zip"), 
							rs.getString("phone"), 
							rs.getString("email"), 
							rs.getInt("manager")
					);
				}
				
				System.out.println(" *******employee by id is:*******");
			} catch(SQLException e) {
				e.printStackTrace();
				log.error(e.getCause());
				log.error(e.getMessage());
			}
			return null;
		}
	 public Employee getEmployeeByIdAndName(String employeeId, String fname, String lname) {
			try {
				String sql = String.format("SELECT * FROM employees WHERE employeeId = ? AND fname = ? AND lname = ?");
				
				Connection conn = DBUtil.getConnection();
				if(conn == null) {
					log.warn("Problem connectiong to jdbc");
					return null;
				}
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1, employeeId);
				ps.setString(2, fname);
				ps.setString(3, lname);
				
				ResultSet rs = ps.executeQuery();
				
				while(rs.next()) {
					return new Employee(
							rs.getInt("u_id"),
							rs.getString("fname"),
							rs.getString("lname"), 
							rs.getString("employeeid"), 
							Position.fromString(rs.getString("position")), 
							rs.getString("street"), 
							rs.getString("city"), 
							rs.getString("state"), 
							rs.getString("zip"), 
							rs.getString("phone"), 
							rs.getString("email"), 
							rs.getInt("manager")
					);
				}
				
				System.out.println("***********employee by name and id is:************");
			} catch(SQLException e) {
				e.printStackTrace();
				log.error(e.getCause());
				log.error(e.getMessage());
			}
			
			return null;
		}
	 public Employee getEmployeeById(String employeeId) {
			try {
				String sql = String.format("SELECT * FROM employees WHERE employeeId = ?");
				
				Connection conn = DBUtil.getConnection();
				if(conn == null) {
					log.warn("Problem connectiong to jdbc");
					return null;
				}
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1, employeeId);
				
				ResultSet rs = ps.executeQuery();
				
				while(rs.next()) {
					return new Employee(
							rs.getInt("u_id"),
							rs.getString("fname"),
							rs.getString("lname"), 
							rs.getString("employeeid"), 
							Position.fromString(rs.getString("position")), 
							rs.getString("street"), 
							rs.getString("city"), 
							rs.getString("state"), 
							rs.getString("zip"), 
							rs.getString("phone"), 
							rs.getString("email"), 
							rs.getInt("manager")
					);
				}
				
				System.out.println("**************emp by id :***************");
			} catch(SQLException e) {
				e.printStackTrace();
				log.error(e.getCause());
				log.error(e.getMessage());
			}
			return null;
		}
	 public List<Employee> getAllEmployees() {
			try {
				String sql = "SELECT * FROM employees";
				
				Connection conn = DBUtil.getConnection();
				if(conn == null) {
					log.warn("Problem connectiong to jdbc");
					return null;
				}
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery();
				
				List<Employee> employees = new ArrayList<Employee>();
				
				while(rs.next()) {
					employees.add(new Employee(
							rs.getInt("u_id"),
							rs.getString("fname"),
							rs.getString("lname"), 
							rs.getString("employeeid"), 
							Position.fromString(rs.getString("position")), 
							rs.getString("street"), 
							rs.getString("city"), 
							rs.getString("state"), 
							rs.getString("zip"), 
							rs.getString("phone"), 
							rs.getString("email"), 
							rs.getInt("manager")
					));
				}
				
				return employees;
				System.out.println("**********Employee details are:************");
				
			} catch(SQLException e) {
				e.printStackTrace();
				log.error(e.getCause());
				log.error(e.getMessage());
			}
			return null;
		}

	 public void updateEmployee(Employee employee, EmpField field, String newVal) {
			try {
				String sql = String.format("UPDATE employees SET %s = ? WHERE employeeid = ?", 
						field.getField()
				);
				
				Connection conn = DBUtil.getConnection();
				if(conn == null) {
					log.warn("Problem connectiong to jdbc");
				}
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1, newVal);
				ps.setString(2, employee.getEmployeeId());
				ps.executeUpdate();
				System.out.println("**********Employee updated**********");
			} catch(SQLException e) {
				e.printStackTrace();
				log.error(e.getCause());
				log.error(e.getMessage());
			}
		}
		
	 public void updateEmployee(Employee employee, Position newPos) {
			try {
				String sql = "UPDATE employees SET position = ? WHERE employeeid = ?";
				
				Connection conn = DBUtil.getConnection();
				if(conn == null) {
					log.warn("Problem connectiong to jdbc");
				}
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1, newPos.getPosition());
				ps.setString(2, employee.getEmployeeId());
				ps.executeUpdate();
				System.out.println("**********Emp updated************");
			} catch(SQLException e) {
				e.printStackTrace();
				log.error(e.getCause());
				log.error(e.getMessage());
			}
		}
	 public void deleteEmployee(Employee employee) {
			try {
				String sql = "DELETE FROM employees WHERE employeeid = ?";
				
				Connection conn = JDBCConnection.getConnection();
				if(conn == null) {
					log.warn("Problem connectiong to jdbc");
				}
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1, employee.getEmployeeId());
				ps.executeUpdate();
				System.out.println("*************employee deleted***********");
			} catch(SQLException e) {
				e.printStackTrace();
				log.error(e.getCause());
				log.error(e.getMessage());
				
			}
		}
	}
		
