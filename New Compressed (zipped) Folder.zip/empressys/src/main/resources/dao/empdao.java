package dao;
import entity.ReimbursementRequest;
import entity.Employee;

public interface empdao{
	 Employee login(String userId,String password);
	 void logout();
	 List<ReimbursementRequest> getPendingReimbursementRequest(int userId);
	 List<ReimbursementRequest> getResolvedReimbursementRequest(int userId);
	 Employee getProfile(int userId);
	 boolean updateProfile(Employee e);
}

