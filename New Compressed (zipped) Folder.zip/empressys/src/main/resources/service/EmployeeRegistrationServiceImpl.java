package service;
import dao.empregdaoimpl;
import model.Employee;
public class EmployeeRegistrationServiceImpl implements  EmployeeRegistrationService{
	empregdaoimpl employeeDao=new empregdaoimpl();
	 public void addEmployee(Employee e) {
		 employeeDao.addEmployee(e);
		 
	 }
	 

}
