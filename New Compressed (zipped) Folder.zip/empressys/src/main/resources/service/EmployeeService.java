package service;
import entity.ReimbursementRequest;
import entity.Employee;

public interface EmployeeService {
	 Employee login(String userId,String password);
	 void logout();
	 List<ReimbursementRequest> getPendingReimbursementRequest(int userId);
	 List<ReimbursementRequest> getResolvedReimbursementRequest(int userId);
	 Employee getProfile(int userId);
	 boolean updateProfile(Employee e);
}

