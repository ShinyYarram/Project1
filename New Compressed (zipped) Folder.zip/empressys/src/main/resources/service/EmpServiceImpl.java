package service;
import java.util.List;

import dao.empdao;
import dao.empdaoimpl;
import entity.ReimbursementRequest;
import entity.Employee;

public class EmpServiceImpl implements EmployeeService {
	private empdao ed=new empdaoimpl();

	public Employee login(String userId, String password) {
		Employee e=ed.login(userId, password);
		return e;
	}

	public void logout() {
		// TODO Auto-generated method stub
	}

	public List<ReimbursementRequest> getPendingReimbursementRequest(int userId) {
		ed.getPendingReimbursementRequest(userId);
		return null;
	}

	public List<ReimbursementRequest> getResolvedReimbursementRequest(int userId) {
		ed.getResolvedReimbursementRequest(userId);
		return null;
	}

	public Employee getProfile(int userId) {
		ed.getProfile(userId);
		return null;
	}

	public boolean updateProfile(Employee e) {
		ed.updateProfile(e);
		return false;
}
}