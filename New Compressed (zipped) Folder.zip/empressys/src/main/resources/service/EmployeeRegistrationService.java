package service;
import model.Employee;
public interface EmployeeRegistrationService {
	public void addEmployee(Employee e)

}
